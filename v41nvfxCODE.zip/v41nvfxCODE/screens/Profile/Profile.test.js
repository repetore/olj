import 'react-native';
import React from 'react';
import Profile from './Profile';
import { render, screen } from '@testing-library/react-native';

describe('Profile Component', () => {
    test('renders correctly with expected text', () => {
        render(<Profile />);
        
        // Проверка, что текст "Экран профиля" отображается на экране
        expect(screen.getByText('Экран профиля')).toBeTruthy();
    });
});